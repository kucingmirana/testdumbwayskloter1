<?php include("config.php"); ?>

<!doctype html>
<html>
<head>
	<style>
	.topnav {
	  overflow: hidden;
	}
	.topnav a {
	  float: left;
	  text-align: center;
	  padding: 14px 16px;
	  text-decoration: none;
	  font-size: 17px;
	}
	.topnav button {
	  float: left;
	  text-align: center;
	  padding: 14px 16px;
	  font-size: 12px;
	}
	</style>
	<title>HOME</title>
</head>
<body>
	<header>
		<h3 style="text-align: center;" >DUMB GRAM</h3>
	</header>

	<div class="topnav">
		<a href="addblog.php">Add Image Blog</a>
		
	</div>

	<table border="1">
	 <thead>
	  <tr>
	   <th>No</th>
	   <th>Nama Produk</th>
	   <th>Gambar</th>
	   <th>konten</th>
	   <th>user</th>
	  </tr>
	 </thead>
	 <tbody>
	  <?php
	   $no=1;
	   $sql=mysqli_query($db , "SELECT * FROM image_blog ");
	   while ($data=mysqli_fetch_array($sql)) {
	  ?>
	   <tr>
	    <td><?=$no++?></td>
	    <td><?=$data['title']?></td>
	    <td><img src="gambar/<?=$data['file']?>" width="100"></td>
	    <td><?=$data['content']?></td>
	    <td><?=$data['user_id']?></td>
	    <td>
	    </td>
	   </tr>
	  <?php
	   }
	  ?>
	 </tbody>
	</table>

</body>
</html>