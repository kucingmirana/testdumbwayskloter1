<?php include("config.php"); ?>

<header>
		<h3>Formulir Add Image Blog</h3>
</header>

<form action="addblog.php" method="POST" enctype='multipart/form-data'>
	<p>
		<label for="title">Title:</label>
		<input type="text" name="title" required placeholder="title">
	</p>
	<p>
		<label for="user">User:</label>
		<input type="text" name="user" required placeholder="nama user">
	</p>
	<p>
		<label for="content">Isi content:</label>
		<input type="text" name="content" required placeholder="isi content">
	</p>
	<p>
		<td>Upload Image</td>
		<td><input type="file" name="filegambar" id="filegambar"></td>
	</p>
	<p>
		<input type="submit" name="upload" value="upload">
	</p>

</form>

<?php

if( isset($_POST['upload']) ){

    $title = $_POST['title'];
    $user = $_POST['user'];
    $content = $_POST['content'];
    $tempdir = "gambar/"; 
        if (!file_exists($tempdir))
        mkdir($tempdir,0755); 
        //gambar akan di simpan di folder gambar
        $target_path = $tempdir . basename($_FILES['filegambar']['name']);

        //nama gambar
        $nama_gambar=$_FILES['filegambar']['name'];
        //ukuran gambar
        $ukuran_gambar = $_FILES['filegambar']['size']; 

        $fileinfo = @getimagesize($_FILES["filegambar"]["tmp_name"]);
        //lebar gambar
        $width = $fileinfo[0];
        //tinggi gambar
        $height = $fileinfo[1]; 
        if($ukuran_gambar > 81920){ 
            echo 'Ukuran gambar melebihi 80kb';
        }else if ($width > "480" || $height > "640") {
             echo 'Ukuran gambar harus 480x640';
        }else{
            if (move_uploaded_file($_FILES['filegambar']['tmp_name'], $target_path)) {
                
                $sql = "INSERT INTO image_blog(title,file,content,user_id) VALUES('$title', '$nama_gambar', '$content', '$user')";

                $query = mysqli_query($db, $sql);
                echo 'Simpan data berhasil';
            } else {
                echo 'Simpan data gagal';
            }
        } 

}

?>

